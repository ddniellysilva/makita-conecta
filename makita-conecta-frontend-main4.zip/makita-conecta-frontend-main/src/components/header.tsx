"use client"

import MakitaLogo from "@/assets/makita-conecta-logo.svg"

export function Header() {
  return (
    <header
      className="sticky top-0 z-50 bg-white border-b border-gray-100"
      style={{ borderColor: "rgba(47, 27, 18, 0.1)" }}
    >
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center cursor-pointer group hover:opacity-80 transition-opacity">
          <img src={MakitaLogo} alt="Makita Conecta" className="h-10 w-auto" />
        </div>

        <div className="hidden md:flex items-center gap-8">
          <a
            href="#por-que-adotar"
            className="text-sm font-medium transition-colors hover:opacity-70"
            style={{ color: "var(--ink)" }}
          >
            Por que adotar?
          </a>
          <a
            href="#animais"
            className="text-sm font-medium transition-colors hover:opacity-70"
            style={{ color: "var(--ink)" }}
          >
            Animais
          </a>
          <a
            href="#sobre"
            className="text-sm font-medium transition-colors hover:opacity-70"
            style={{ color: "var(--ink)" }}
          >
            Sobre
          </a>
          <button
            className="px-6 py-2 rounded-lg font-medium text-white transition-all hover:shadow-lg transform hover:scale-105"
            style={{ backgroundColor: "var(--accent)" }}
          >
            Fazer adoção
          </button>
        </div>

        <div className="md:hidden">
          <button
            className="w-10 h-10 rounded-lg flex items-center justify-center transition-colors"
            style={{ backgroundColor: "var(--sky)", color: "var(--brand)" }}
          >
            <span className="text-xl">≡</span>
          </button>
        </div>
      </nav>
    </header>
  )
}
