import { createContext, useState, useEffect } from "react";

// URL do Backend Flask
const API_URL = "http://127.0.0.1:5000";

type UserDTO = {
    name: string
    email: string
    // A senha não deve ser armazenada no estado do frontend por segurança
    password?: string 
}

type SessionContextProps = {
    userLogged: UserDTO | null
    signIn: (email: string, password: string) => Promise<void>
    signUp: (name: string, email: string, password: string) => Promise<void>
    signOut: () => void
}

export const SessionContext = createContext({} as SessionContextProps)

type SessionProviderProps = {
    children: React.ReactNode
}

export function SessionProvider({children}: SessionProviderProps) {
    const [userLogged, setUserLogged] = useState<UserDTO | null>(null)

    // Efeito para verificar se já existe um token salvo ao recarregar a página
    useEffect(() => {
        // MUDANÇA: Usando sessionStorage em vez de localStorage
        const token = sessionStorage.getItem("access_token");
        if (token) {
            // Se tem token, tenta buscar o perfil do usuário
            fetchUserProfile(token);
        }
    }, []);

    async function fetchUserProfile(token: string) {
        try {
            const response = await fetch(`${API_URL}/api/profile`, {
                headers: {
                    "Authorization": `Bearer ${token}`
                }
            });
            if (response.ok) {
                const userData = await response.json();
                setUserLogged({
                    name: userData.name,
                    email: userData.email
                });
            } else {
                // Se o token for inválido, faz logout
                signOut();
            }
        } catch (error) {
            console.error("Erro ao recuperar sessão:", error);
            signOut();
        }
    }

    async function signIn(email: string, password: string) {
        try {
            const response = await fetch(`${API_URL}/api/login`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ email, password }),
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || "Erro ao fazer login");
            }

            // 1. Salva o token na SESSÃO (apaga ao fechar o navegador)
            sessionStorage.setItem("access_token", result.access_token);

            // 2. Busca os dados do usuário (Nome, etc) usando o token
            await fetchUserProfile(result.access_token);

        } catch (error) {
            throw error;
        }
    }

    async function signUp(name: string, email: string, password: string) {
        try {
            const response = await fetch(`${API_URL}/api/register`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ name, email, password }),
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || "Erro ao cadastrar");
            }

            // Opcional: Já fazer o login automático após o cadastro
            // await signIn(email, password); 

        } catch (error) {
            throw error;
        }
    }

    function signOut() {
        // Limpa o token da sessão
        sessionStorage.removeItem("access_token");
        setUserLogged(null);
    }

    return (
        <SessionContext.Provider value={{userLogged, signIn, signUp, signOut}}>
            {children}
        </SessionContext.Provider>
    )
}